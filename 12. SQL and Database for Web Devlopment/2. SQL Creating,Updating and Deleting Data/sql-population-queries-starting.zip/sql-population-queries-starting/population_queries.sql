-- This is the first query:

SELECT DISTINCT year from population_years;

-- Add your additional queries below:

